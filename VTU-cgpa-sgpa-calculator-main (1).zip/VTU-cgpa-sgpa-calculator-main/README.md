# VTU - SGPA and CGPA calculator for 2018/2017 scheme B.E/B.Tech students

Link => https://jks46.github.io/VTU-cgpa-sgpa-calculator/

### To Do

- [ ] local storage for storing different sem data and loading it in cgpa page

![image](https://user-images.githubusercontent.com/93701274/205349148-94f4136e-697a-4c39-9d64-dc22e91a05d6.png)
![image](https://user-images.githubusercontent.com/93701274/205349161-f9035ba2-4dee-4c57-8eec-a6adb3e5fcdc.png)
![image](https://user-images.githubusercontent.com/93701274/205349173-7dfd8064-b979-4b37-8822-110ee59798fc.png)
